1. 将APP程序生成得Appl.hex文件和FBL程序生成的Fbl_CC.hex拷贝到当前文件夹。
2. ApplHexMake.bat文件内的路径为本电脑得HexView安装目录。
3. PSI_Fill.hex文件为APP填充尾。
4. 双击执行AllHexMake.bat文件。