0909更新：
    1. 将APP程序生成得Appl.hex文件拷贝到当前文件夹。
    2. ApplHexMake.bat文件内的路径为本电脑得HexView安装目录。
    3. 打开V71BinMakerAll.exe文件，选择对应的版本号，然后点击生成.bin文件。
    
    
    
    
作废：
    1. 将APP程序生成得Appl.hex文件拷贝到当前文件夹。
    2. ApplHexMake.bat文件内的路径为本电脑得HexView安装目录。
    3. 打开BinHeaderForm.exe文件，先点击执行bat文件，选择对应得版本号，然后点击生成.bin文件。


    